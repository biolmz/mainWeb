# -*- coding: utf-8 -*-
"""
第 6 章  分组聚合与数据透视：分析的核心武器
============================================
包含：groupby 分组统计 / 多列分组 / 多聚合函数 / 命名聚合 / transform / pivot_table / crosstab

"分组-聚合"是 pandas 最强大的思想：
  split（切分）→ apply（应用函数）→ combine（合并结果）

运行方式：
    cd code
    python 05_pandas分组聚合.py
"""
import pandas as pd
import common_style

common_style.setup()
import matplotlib.pyplot as plt  # noqa: E402

IMG = common_style.img_dir()

sales = pd.read_csv("data/sales_2024.csv", parse_dates=["日期"])
sales["月份"] = sales["日期"].dt.month
print("数据规模:", sales.shape)

# ----------------------------------------------------------------------
# 6.1 基础分组：groupby + 单个聚合
# ----------------------------------------------------------------------
print("\n【6.1 基础分组】")
print("各区域订单数:")
print(sales.groupby("区域")["订单号"].count().sort_values(ascending=False).to_string())

print("\n各区域销售额合计（万元）:")
print((sales.groupby("区域")["销售额"].sum() / 10000).round(1).to_string())

print("\n各品类平均毛利:")
print(sales.groupby("品类")["毛利"].mean().round(2).to_string())

# ----------------------------------------------------------------------
# 6.2 多列分组：一次得到多个维度组合的统计
# ----------------------------------------------------------------------
print("\n【6.2 多列分组】")
g = sales.groupby(["区域", "品类"])["销售额"].sum().sort_values(ascending=False)
print("区域×品类销售额 Top 6:")
print((g / 10000).round(1).head(6).to_string())

# ----------------------------------------------------------------------
# 6.3 多聚合函数：agg 一次算出多个指标
# ----------------------------------------------------------------------
print("\n【6.3 agg 多聚合】")
stat = sales.groupby("区域").agg(
    订单数=("订单号", "count"),
    总销售额=("销售额", "sum"),
    平均客单价=("销售额", "mean"),
    销量中位数=("销量", "median"),
    最高单笔=("销售额", "max"),
).sort_values("总销售额", ascending=False)
stat["总销售额(万元)"] = (stat["总销售额"] / 10000).round(1)
print(stat.round(1).to_string())

# 更简单的写法：直接传聚合函数列表
print("\nagg(['sum','mean']) 示例（前3行）:")
print(sales.groupby("品类")[["销售额", "毛利"]].agg(["sum", "mean"]).round(0).head(3).to_string())

# ----------------------------------------------------------------------
# 6.4 transform：把分组统计广播回每一行
# ----------------------------------------------------------------------
print("\n【6.4 transform 应用】")
# 需求：每个订单，与其所在品类的平均毛利比较，是否高于同类平均
sales2 = sales.copy()
sales2["品类平均毛利"] = sales2.groupby("品类")["毛利"].transform("mean")
sales2["高于同类平均"] = sales2["毛利"] > sales2["品类平均毛利"]
print("高毛利订单占比:", round(sales2["高于同类平均"].mean() * 100, 1), "%")
print("\n前 5 行（新增两列）:")
print(sales2[["商品", "毛利", "品类平均毛利", "高于同类平均"]].head(5).to_string(index=False))

# ----------------------------------------------------------------------
# 6.5 数据透视表 pivot_table：Excel 透视表的 pandas 版
# ----------------------------------------------------------------------
print("\n【6.5 pivot_table 数据透视】")
pivot = pd.pivot_table(sales, values="销售额", index="区域", columns="品类",
                       aggfunc="sum", margins=True, margins_name="合计")
print("区域×品类 销售额透视表（万元）:")
print((pivot / 10000).round(1).to_string())

pivot2 = pd.pivot_table(sales, values="销售额", index="月份", columns="区域",
                        aggfunc="sum")
print("\n月份×区域 销售额透视表（万元，前 3 行）:")
print((pivot2 / 10000).round(1).head(3).to_string())

# ----------------------------------------------------------------------
# 6.6 交叉表 crosstab：分类变量的频数统计
# ----------------------------------------------------------------------
print("\n【6.6 crosstab 交叉表】")
ct = pd.crosstab(sales["区域"], sales["支付方式"], normalize="index").round(3) * 100
print("各区域支付方式占比（%）：")
print(ct.to_string())

ct2 = pd.crosstab(sales["品类"], sales["会员等级"])
print("\n品类×会员等级 订单数:")
print(ct2.to_string())

# ----------------------------------------------------------------------
# 6.7 可视化：把分组结果画出来
# ----------------------------------------------------------------------
# 柱状图：各区域销售额
region_sum = sales.groupby("区域")["销售额"].sum().sort_values(ascending=False)
fig, ax = plt.subplots(figsize=(8, 4.2))
bars = ax.bar(region_sum.index, region_sum.values / 10000, color=common_style.COLORS,
              edgecolor="white")
for b, v in zip(bars, region_sum.values / 10000):
    ax.text(b.get_x() + b.get_width() / 2, v + 0.8, f"{v:.1f}",
            ha="center", fontsize=11, fontweight="bold")
ax.set_title("2024 年各区域销售额对比（万元）")
ax.set_ylabel("销售额（万元）")
ax.grid(axis="y", alpha=0.3)
fig.tight_layout()
fig.savefig(f"{IMG}/fig_group_region.png", bbox_inches="tight")
print("\n已保存图表:", f"{IMG}/fig_group_region.png")

# 堆叠柱状图：区域 × 品类的销售结构
pivot_s = pd.pivot_table(sales, values="销售额", index="区域", columns="品类", aggfunc="sum")
pivot_s = pivot_s.reindex(region_sum.index)
fig, ax = plt.subplots(figsize=(9, 4.6))
bottom = None
for cat in pivot_s.columns:
    ax.bar(pivot_s.index, pivot_s[cat] / 10000, label=cat, bottom=bottom,
           color=None, edgecolor="white", linewidth=0.6)
    bottom = (bottom if bottom is not None else 0) + (pivot_s[cat] / 10000).values
ax.set_title("2024 年各区域销售结构（按品类堆叠，万元）")
ax.set_ylabel("销售额（万元）")
ax.legend(ncol=3, fontsize=10)
fig.tight_layout()
fig.savefig(f"{IMG}/fig_group_stack.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_group_stack.png")

print("\n✅ 第 6 章演示完成！")
