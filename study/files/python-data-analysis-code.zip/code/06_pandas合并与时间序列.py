# -*- coding: utf-8 -*-
"""
第 7 章  多表合并与时间序列分析
===============================
包含：concat 拼接 / merge 各类连接 / 时间序列重采样 / 滚动窗口 / 差分与收益率

运行方式：
    cd code
    python 06_pandas合并与时间序列.py
"""
import numpy as np
import pandas as pd
import common_style

common_style.setup()
import matplotlib.pyplot as plt  # noqa: E402

IMG = common_style.img_dir()

# ----------------------------------------------------------------------
# 7.1 concat：按行 / 按列拼接
# ----------------------------------------------------------------------
print("【7.1 concat 拼接】")
q1 = pd.DataFrame({"月份": ["1月", "2月", "3月"], "销量": [120, 150, 132]})
q2 = pd.DataFrame({"月份": ["4月", "5月", "6月"], "销量": [180, 200, 210]})
year = pd.concat([q1, q2], ignore_index=True)
print("上半年销量表:\n", year.to_string(index=False))

# 按列拼接：两张各有部分信息的表
info_a = pd.DataFrame({"学号": [1, 2, 3], "姓名": ["甲", "乙", "丙"]})
info_b = pd.DataFrame({"学号": [1, 2, 3], "班级": ["1班", "2班", "1班"]})
print("\n按列拼接:\n", pd.concat([info_a, info_b], axis=1).to_string(index=False))

# ----------------------------------------------------------------------
# 7.2 merge：SQL 风格的连接
# ----------------------------------------------------------------------
print("\n【7.2 merge 连接】")
orders = pd.DataFrame({
    "订单号": ["A1", "A2", "A3", "A4"],
    "客户ID": [101, 102, 101, 103],
    "金额":   [300, 500, 200, 400],
})
customers = pd.DataFrame({
    "客户ID": [101, 102, 103, 104],
    "姓名":   ["张三", "李四", "王五", "赵六"],
    "城市":   ["北京", "上海", "广州", "深圳"],
})
print("订单表:\n", orders.to_string(index=False))
print("\n客户表:\n", customers.to_string(index=False))

merged = pd.merge(orders, customers, on="客户ID", how="inner")
print("\ninner 内连接（仅双方都有的客户）:")
print(merged.to_string(index=False))

merged_left = pd.merge(orders, customers, on="客户ID", how="left")
print("\nleft 左连接（保留全部订单，客户缺失则 NaN）:")
print(merged_left.to_string(index=False))

# ----------------------------------------------------------------------
# 7.3 时间序列：股票数据
# ----------------------------------------------------------------------
print("\n【7.3 时间序列】")
stock = pd.read_csv("data/stock_daily.csv", parse_dates=["日期"])
stock = stock.sort_values("日期").set_index("日期")
print("股票数据（500 个交易日）:")
print(stock.head(3).round(2).to_string())

# 重采样：月度聚合
monthly = stock["收盘"].resample("ME").last()
monthly_return = monthly.pct_change().dropna() * 100
print("\n月度收盘价（最后 3 个月）:")
print(monthly.tail(3).round(2).to_string())

# 滚动窗口：20 日均线
stock["MA20"] = stock["收盘"].rolling(20).mean()
stock["MA60"] = stock["收盘"].rolling(60).mean()
print("\n最近 5 个交易日的收盘价与均线:")
print(stock[["收盘", "MA20", "MA60"]].tail(5).round(2).to_string())

# 收益率与波动
stock["日收益率"] = stock["收盘"].pct_change() * 100
print("\n日收益率统计:")
print(stock["日收益率"].describe().round(3).to_string())
print("\n历史最大单日跌幅: %.2f%%" % stock["日收益率"].min())
print("历史最大单日涨幅: +%.2f%%" % stock["日收益率"].max())

# 绘制：收盘价 + 均线 + 成交量
fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True,
                         gridspec_kw={"height_ratios": [3, 1]})
axes[0].plot(stock.index, stock["收盘"], color=common_style.PALETTE["blue"], lw=1.4, label="收盘价")
axes[0].plot(stock.index, stock["MA20"], color=common_style.PALETTE["orange"], lw=1.4, label="20日均线")
axes[0].plot(stock.index, stock["MA60"], color=common_style.PALETTE["purple"], lw=1.4, label="60日均线")
axes[0].set_title("股票日线：收盘价与均线（MA20/MA60）")
axes[0].set_ylabel("价格（元）")
axes[0].legend(loc="upper left")

colors = np.where(stock["收盘"].diff() >= 0, common_style.PALETTE["red"], common_style.PALETTE["green"])
axes[1].bar(stock.index, stock["成交量(手)"], color=colors, width=0.8, alpha=0.75)
axes[1].set_title("成交量（红涨绿跌）")
axes[1].set_ylabel("成交量（手）")
fig.tight_layout()
fig.savefig(f"{IMG}/fig_ts_stock.png", bbox_inches="tight")
print("\n已保存图表:", f"{IMG}/fig_ts_stock.png")

# 月度重采样可视化
monthly_amount = stock["收盘"].resample("ME").mean()
fig, ax = plt.subplots(figsize=(9, 4))
ax.plot(monthly_amount.index, monthly_amount.values, marker="o", color=common_style.PALETTE["teal"])
for x, y in zip(monthly_amount.index, monthly_amount.values):
    ax.annotate(f"{y:.1f}", (x, y), textcoords="offset points", xytext=(0, 8), ha="center", fontsize=9)
ax.set_title("月度平均收盘价走势（ME 重采样）")
ax.set_ylabel("价格（元）")
ax.grid(alpha=0.3)
fig.tight_layout()
fig.savefig(f"{IMG}/fig_ts_monthly.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_ts_monthly.png")

# ----------------------------------------------------------------------
# 7.4 时间序列特征：滞后、差分、累计收益
# ----------------------------------------------------------------------
print("\n【7.4 常用时间序列操作】")
print("shift 滞后一天:", stock["收盘"].shift(1).tail(2).round(2).to_list())
print("diff 一阶差分:", stock["收盘"].diff().tail(2).round(2).to_list())
cum_ret = (1 + stock["日收益率"] / 100).cumprod()
print("累计收益率（最后一天）: %.2f 倍" % cum_ret.iloc[-1])
print("全年交易日数:", len(stock))

print("\n✅ 第 7 章演示完成！")
