# -*- coding: utf-8 -*-
"""
第 4 章  pandas 数据结构与数据读取
===================================
包含：Series / DataFrame / 读取 CSV / 数据查看 / 列与行的筛选 / 排序 / 新增与删除列

运行方式：
    cd code
    python 03_pandas入门.py
"""
import pandas as pd
import common_style

IMG = common_style.img_dir()

print("pandas 版本:", pd.__version__)

# ----------------------------------------------------------------------
# 4.1 Series：带标签的一维数组
# ----------------------------------------------------------------------
print("\n【4.1 Series】")
score = pd.Series([92, 85, 78], index=["语文", "数学", "英语"], name="期末成绩")
print(score)
print("\nscore['数学'] =", score["数学"])
print("score > 80:\n", score[score > 80])
print("均值:", round(score.mean(), 1))

# ----------------------------------------------------------------------
# 4.2 DataFrame：二维表格
# ----------------------------------------------------------------------
print("\n【4.2 DataFrame】")
df = pd.DataFrame({
    "姓名":  ["林小雨", "周子昂", "陈晓芸"],
    "年龄":  [19, 20, 18],
    "专业":  ["计算机", "生物工程", "数据科学"],
    "GPA":   [3.8, 3.5, 4.0],
})
print(df)
print("\ndf.dtypes:\n", df.dtypes)

# ----------------------------------------------------------------------
# 4.3 读取真实数据集：2024 年电商销售订单
# ----------------------------------------------------------------------
sales = pd.read_csv("data/sales_2024.csv", parse_dates=["日期"])
print("\n【4.3 读取 data/sales_2024.csv】")
print("形状 shape:", sales.shape)
print("\n列名:\n", list(sales.columns))
print("\ndtypes:\n", sales.dtypes)

# ----------------------------------------------------------------------
# 4.4 快速查看数据
# ----------------------------------------------------------------------
print("\n【4.4 快速查看】")
print("head() 前 5 行:")
print(sales.head())
print("\ntail(3) 最后 3 行:")
print(sales.tail(3))
print("\ninfo() 数据概要:")
print(sales.info())
print("\ndescribe() 数值列统计摘要:")
print(sales.describe().round(2))

# 唯一值统计
print("\n品类分布 value_counts:")
print(sales["品类"].value_counts())
print("\n区域分布占比（前3）:")
print(sales["区域"].value_counts(normalize=True).head(3).round(3).to_string())

# ----------------------------------------------------------------------
# 4.5 数据筛选：loc / iloc / 布尔条件
# ----------------------------------------------------------------------
print("\n【4.5 数据筛选】")
print("iloc 第 10~12 行（索引位置）:")
print(sales.iloc[10:13, [0, 3, 4]])
print("\nloc 筛选指定列:")
print(sales.loc[0:2, ["订单号", "城市", "销售额"]])
print("\n布尔条件: 销售额 > 5000 的订单数:", (sales["销售额"] > 5000).sum())
big_orders = sales[sales["销售额"] > 5000]
print("其中华东区域占:", (big_orders["区域"] == "华东").sum(), "单")
print("\n多条件: 华南 & 数码家电 & 销售额>3000:")
sel = sales[(sales["区域"] == "华南") & (sales["品类"] == "数码家电") & (sales["销售额"] > 3000)]
print("命中", len(sel), "行，合计销售额", round(sel["销售额"].sum(), 2))

# isin 用法
print("\nisin: 华东/华南的订单量:", sales["区域"].isin(["华东", "华南"]).sum())

# ----------------------------------------------------------------------
# 4.6 排序
# ----------------------------------------------------------------------
print("\n【4.6 排序】")
print("销售额最高的 5 笔订单:")
print(sales.sort_values("销售额", ascending=False).head(5)[["订单号", "商品", "销售额"]].to_string(index=False))
print("\n先按区域、再按销售额降序:")
print(sales.sort_values(["区域", "销售额"], ascending=[True, False]).head(3)[["区域", "商品", "销售额"]].to_string(index=False))

# ----------------------------------------------------------------------
# 4.7 新增列、删除列、重命名
# ----------------------------------------------------------------------
print("\n【4.7 新增 / 删除 / 重命名列】")
sales2 = sales.copy()
sales2["利润率"] = (sales2["毛利"] / sales2["销售额"]).round(3)      # 新增列
sales2["星期"] = sales2["日期"].dt.day_name()                          # 由日期派生
sales2["订单金额分级"] = pd.cut(sales2["销售额"], [0, 500, 2000, 10000],
                             labels=["小额", "中额", "大额"])
print("新增 3 列后的列名:", list(sales2.columns[-3:]))
print("\n按订单金额分级统计订单数:")
print(sales2["订单金额分级"].value_counts().to_string())
sales2 = sales2.drop(columns=["星期"])                                 # 删除列
sales2 = sales2.rename(columns={"销售额": "金额"})
print("\n删除星期列、重命名销售额→金额:", "金额" in sales2.columns, "且", "销售额" not in sales2.columns)

print("\n✅ 第 4 章演示完成！")
