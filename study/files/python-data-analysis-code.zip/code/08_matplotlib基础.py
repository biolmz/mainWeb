# -*- coding: utf-8 -*-
"""
第 9 章  matplotlib 可视化基础
===============================
包含：画布与坐标轴 / 折线图 / 柱状图（分组·堆叠·水平）/ 饼图 / 散点图 / 直方图 / 箱线图

核心思想：plt.subplots() 创建画布 → 绘图函数画数据 → 设置标题标签 → 保存/显示

运行方式：
    cd code
    python 08_matplotlib基础.py
"""
import numpy as np
import pandas as pd
import common_style

common_style.setup()
import matplotlib.pyplot as plt  # noqa: E402

IMG = common_style.img_dir()

sales = pd.read_csv("data/sales_2024.csv", parse_dates=["日期"])
tips = pd.read_csv("data/tips.csv")

# ----------------------------------------------------------------------
# 9.1 折线图：趋势的天然表达
# ----------------------------------------------------------------------
print("【9.1 折线图】")
monthly = sales.groupby(sales["日期"].dt.month)["销售额"].sum()
fig, ax = plt.subplots(figsize=(9, 4.2))
ax.plot(monthly.index, monthly.values / 10000, marker="o", color=common_style.PALETTE["blue"],
        linewidth=2.2, markersize=6, label="月度销售额")
ax.axvline(6, color=common_style.PALETTE["orange"], ls="--", alpha=0.7, label="618 大促")
ax.axvline(11, color=common_style.PALETTE["red"], ls="--", alpha=0.7, label="双 11")
ax.set_xticks(monthly.index)
ax.set_xticklabels([f"{m}月" for m in monthly.index])
ax.set_title("2024 年电商平台月度销售额趋势（万元）")
ax.set_xlabel("月份")
ax.set_ylabel("销售额（万元）")
ax.grid(alpha=0.3)
ax.legend()
fig.tight_layout()
fig.savefig(f"{IMG}/fig_mpl_line.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_mpl_line.png")

# ----------------------------------------------------------------------
# 9.2 柱状图：不同类别的比较
# ----------------------------------------------------------------------
print("\n【9.2 柱状图】")
# 水平柱状图：会员等级销售额
member = sales.groupby("会员等级")["销售额"].sum().sort_values()
fig, ax = plt.subplots(figsize=(8, 4.2))
bars = ax.barh(member.index, member.values / 10000, color=[common_style.PALETTE[c]
               for c in ["gray", "blue", "gold", "purple"]])
for b, v in zip(bars, member.values / 10000):
    ax.text(v + 1, b.get_y() + b.get_height() / 2, f"{v:.0f}",
            va="center", fontsize=10, fontweight="bold")
ax.set_title("各会员等级贡献的销售额（万元）")
ax.set_xlabel("销售额（万元）")
fig.tight_layout()
fig.savefig(f"{IMG}/fig_mpl_barh.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_mpl_barh.png")

# 分组柱状图：各区域不同支付方式订单数
pay_ct = pd.crosstab(sales["区域"], sales["支付方式"])
fig, ax = plt.subplots(figsize=(10, 4.4))
x = np.arange(len(pay_ct.index))
width = 0.16
for i, col in enumerate(pay_ct.columns):
    ax.bar(x + i * width, pay_ct[col], width, label=col,
           color=common_style.COLORS[i % len(common_style.COLORS)])
ax.set_xticks(x + width * 2)
ax.set_xticklabels(pay_ct.index)
ax.set_title("各区域不同支付方式的订单量")
ax.set_ylabel("订单数")
ax.legend(ncol=5, fontsize=9)
fig.tight_layout()
fig.savefig(f"{IMG}/fig_mpl_grouped_bar.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_mpl_grouped_bar.png")

# ----------------------------------------------------------------------
# 9.3 饼图：构成比例（环形图更现代）
# ----------------------------------------------------------------------
print("\n【9.3 饼图】")
cat = sales.groupby("品类")["销售额"].sum()
fig, ax = plt.subplots(figsize=(7, 5))
wedges, texts, autotexts = ax.pie(
    cat.values, labels=cat.index, autopct="%.1f%%",
    colors=common_style.COLORS, startangle=90, counterclock=False,
    wedgeprops={"edgecolor": "white", "linewidth": 2})
for t in autotexts:
    t.set_fontsize(11)
    t.set_color("white")
    t.set_fontweight("bold")
ax.set_title("六大品类销售额占比")
fig.tight_layout()
fig.savefig(f"{IMG}/fig_mpl_pie.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_mpl_pie.png")

# ----------------------------------------------------------------------
# 9.4 散点图：两个连续变量的关系
# ----------------------------------------------------------------------
print("\n【9.4 散点图】")
fig, ax = plt.subplots(figsize=(8, 4.6))
for sex, color in zip(["男", "女"], [common_style.PALETTE["blue"], common_style.PALETTE["red"]]):
    sub = tips[tips["性别"] == sex]
    ax.scatter(sub["总消费"], sub["小费"], s=34, alpha=0.65, color=color, label=f"{sex}性顾客")
ax.set_title("餐厅消费与小费的关系（按性别着色）")
ax.set_xlabel("总消费（元）")
ax.set_ylabel("小费（元）")
ax.legend()
fig.tight_layout()
fig.savefig(f"{IMG}/fig_mpl_scatter.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_mpl_scatter.png")

# ----------------------------------------------------------------------
# 9.5 直方图：分布的形状
# ----------------------------------------------------------------------
print("\n【9.5 直方图】")
fig, ax = plt.subplots(figsize=(8, 4.2))
ax.hist(sales["单价"], bins=30, color=common_style.PALETTE["teal"], alpha=0.8,
        edgecolor="white", label="商品单价分布")
ax.axvline(sales["单价"].mean(), color=common_style.PALETTE["red"], ls="--", lw=2,
           label=f"均值 {sales['单价'].mean():.0f} 元")
ax.axvline(sales["单价"].median(), color=common_style.PALETTE["orange"], ls="-.", lw=2,
           label=f"中位数 {sales['单价'].median():.0f} 元")
ax.set_title("商品单价分布（右偏：多数商品便宜，少数很贵）")
ax.set_xlabel("单价（元）")
ax.set_ylabel("订单数")
ax.legend()
fig.tight_layout()
fig.savefig(f"{IMG}/fig_mpl_hist.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_mpl_hist.png")

# ----------------------------------------------------------------------
# 9.6 箱线图：五数概括与异常值
# ----------------------------------------------------------------------
print("\n【9.6 箱线图】")
fig, ax = plt.subplots(figsize=(9, 4.6))
bp_data = [sales.loc[sales["品类"] == c, "单价"].values for c in sales["品类"].unique()]
bp = ax.boxplot(bp_data, labels=sales["品类"].unique(), patch_artist=True)
for patch, color in zip(bp["boxes"], common_style.COLORS):
    patch.set_facecolor(color)
    patch.set_alpha(0.65)
ax.set_title("各品类商品单价分布（箱线图）")
ax.set_ylabel("单价（元）")
ax.grid(axis="y", alpha=0.3)
fig.tight_layout()
fig.savefig(f"{IMG}/fig_mpl_box.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_mpl_box.png")

print("\n✅ 第 9 章演示完成！")
