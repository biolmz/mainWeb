# -*- coding: utf-8 -*-
"""
第 2 章  NumPy 数值计算基础（入门篇）
=====================================
包含：创建数组 / 数组属性 / 索引切片 / 数组运算 / 通用函数 / 聚合统计 / 广播机制

运行方式：
    cd code
    python 01_numpy入门.py
"""
import numpy as np
import common_style

common_style.setup()
import matplotlib.pyplot as plt  # noqa: E402

IMG = common_style.img_dir()

print("=" * 62)
print("NumPy 版本：", np.__version__)
print("=" * 62)

# ----------------------------------------------------------------------
# 2.1 创建数组：numpy 的核心数据结构 ndarray
# ----------------------------------------------------------------------
print("\n【2.1 创建数组】")
a = np.array([1, 2, 3, 4, 5])                 # 从列表创建一维数组
b = np.array([[1, 2, 3], [4, 5, 6]])          # 从嵌套列表创建二维数组（矩阵）
z = np.zeros((2, 3))                           # 全 0 矩阵
o = np.ones(4)                                 # 全 1 数组
e = np.eye(3)                                  # 单位矩阵（对角线为 1）
r = np.arange(0, 10, 2)                        # 等差数列：0,2,4,6,8
l = np.linspace(0, 1, 5)                       # 0~1 之间均匀取 5 个数
print("a =", a)
print("b =\n", b)
print("zeros(2,3) =\n", z)
print("eye(3) =\n", e)
print("arange(0,10,2) =", r)
print("linspace(0,1,5) =", l)

# ----------------------------------------------------------------------
# 2.2 数组属性：形状、维度、数据类型
# ----------------------------------------------------------------------
print("\n【2.2 数组属性】")
print("b.shape =", b.shape, "  维度:", b.ndim, "  元素数:", b.size)
print("a.dtype =", a.dtype)
print("整型数组 a 转为浮点: ", a.astype(np.float64).dtype)

# ----------------------------------------------------------------------
# 2.3 索引与切片：和 Python 列表的切片语法一脉相承
# ----------------------------------------------------------------------
print("\n【2.3 索引与切片】")
arr = np.arange(10)
print("arr =", arr)
print("arr[2]   =", arr[2])       # 第 3 个元素
print("arr[-1]  =", arr[-1])      # 最后一个
print("arr[2:5] =", arr[2:5])     # 切片
print("arr[::-1]=", arr[::-1])    # 反转

mat = np.arange(1, 13).reshape(3, 4)
print("\nmat (3×4) =\n", mat)
print("mat[1, 2]  =", mat[1, 2])     # 第 2 行第 3 列
print("mat[0]     =", mat[0])        # 第 1 行
print("mat[:, 1]  =", mat[:, 1])     # 第 2 列
print("mat[1:, 2:]=\n", mat[1:, 2:])  # 右下角 2×2 子块

# ----------------------------------------------------------------------
# 2.4 数组运算：向量化让代码又快又简洁
# ----------------------------------------------------------------------
print("\n【2.4 数组运算】")
x = np.array([1, 2, 3])
y = np.array([10, 20, 30])
print("x + y  =", x + y)
print("x * 2  =", x * 2)          # 标量广播（每个元素乘 2）
print("x ** 2 =", x**2)
print("x > 1  =", x > 1)          # 逐元素比较，得到布尔数组
print("x @ y  =", x @ y)          # 向量点积：1*10+2*20+3*30

# ----------------------------------------------------------------------
# 2.5 通用函数（ufunc）：对每个元素施以相同数学变换
# ----------------------------------------------------------------------
print("\n【2.5 通用函数】")
vals = np.array([1.0, 4.0, 9.0, 16.0])
print("sqrt :", np.sqrt(vals))
print("log  :", np.round(np.log(vals), 3))
print("exp  :", np.round(np.exp(np.array([0, 1, 2])), 3))
print("sin  :", np.round(np.sin(np.array([0, np.pi / 2, np.pi])), 6))

# ----------------------------------------------------------------------
# 2.6 聚合统计：一行代码搞定描述性统计
# ----------------------------------------------------------------------
print("\n【2.6 聚合统计】")
data = np.array([168, 175, 182, 160, 174, 171, 169, 178, 176, 165])
print("身高数据(cm):", data)
print("总和 sum   =", data.sum())
print("均值 mean  =", round(data.mean(), 2))
print("中位数 med =", np.median(data))
print("标准差 std =", round(data.std(), 2))
print("最大值 max =", data.max(), " 最小值 min =", data.min())
print("最小值位置 argmin =", data.argmin(), "（第", data.argmin() + 1, "个人最矮）")

# axis 参数：按行/按列聚合
m2 = np.arange(1, 7).reshape(2, 3)
print("\nm2 =\n", m2)
print("m2.sum(axis=0) =", m2.sum(axis=0), "  # 每一列求和")
print("m2.sum(axis=1) =", m2.sum(axis=1), "  # 每一行求和")

# ----------------------------------------------------------------------
# 2.7 广播机制：不同形状的数组也能直接运算
# ----------------------------------------------------------------------
print("\n【2.7 广播机制】")
prices = np.array([[100, 200, 300],
                   [400, 500, 600]])
discount = np.array([0.9, 0.8, 0.7])   # 三个品类各自的折扣
print("原价:\n", prices)
print("折扣:", discount)
print("折后价:\n", prices * discount)   # (2,3) 与 (3,) 广播运算

# 生动例子：全班 5 位同学 3 门课的分数，减去每门课的均值（去中心化）
scores = np.array([[88, 72, 90],
                   [95, 68, 85],
                   [70, 80, 92],
                   [82, 75, 78],
                   [91, 88, 95]])
col_mean = scores.mean(axis=0)
print("\n5 位同学 3 门课成绩:\n", scores)
print("各科平均:", col_mean)
print("去中心化后的成绩（每科减去该科均值）:\n", scores - col_mean)

# ----------------------------------------------------------------------
# 2.8 小例子：用 numpy 分析一组模拟的气温数据并绘图
# ----------------------------------------------------------------------
print("\n【2.8 综合小例子：一周气温】")
days = np.array(["周一", "周二", "周三", "周四", "周五", "周六", "周日"])
temps = np.array([12.5, 15.0, 17.5, 14.0, 19.0, 22.0, 20.5])
print("这一周平均气温:", round(temps.mean(), 1), "℃，最高:", temps.max(), "℃，最低:", temps.min(), "℃")
print("最高温出现在:", days[temps.argmax()], "，比整周均值高", round(temps.max() - temps.mean(), 1), "℃")

fig, ax = plt.subplots(figsize=(8, 4.2))
ax.plot(days, temps, marker="o", color=common_style.PALETTE["blue"], label="气温")
ax.axhline(temps.mean(), color=common_style.PALETTE["orange"], ls="--", lw=1.6,
           label=f"周均值 {temps.mean():.1f}℃")
ax.fill_between(range(7), temps, temps.mean(), where=(temps > temps.mean()),
                color=common_style.PALETTE["orange"], alpha=0.15)
ax.set_title("一周气温走势（numpy 聚合 + matplotlib 绘图）")
ax.set_ylabel("气温（℃）")
ax.legend(loc="lower right")
fig.tight_layout()
fig.savefig(f"{IMG}/fig_np_week_temps.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_np_week_temps.png")

print("\n✅ 第 2 章（入门篇）演示完成！")
