# -*- coding: utf-8 -*-
"""
第 10 章  matplotlib 进阶技巧
==============================
包含：多子图布局 / 双 Y 轴 / 填充区域 / 注释与标注 / 颜色映射 / 样式定制 / 极坐标与 3D

"好的图表自己会说话"——进阶技巧的目标就是让图更清晰、更有说服力。

运行方式：
    cd code
    python 09_matplotlib进阶.py
"""
import numpy as np
import pandas as pd
import common_style

common_style.setup()
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.ticker import FuncFormatter

IMG = common_style.img_dir()

sales = pd.read_csv("data/sales_2024.csv", parse_dates=["日期"])
weather = pd.read_csv("data/weather_daily.csv", parse_dates=["日期"])
stock = pd.read_csv("data/stock_daily.csv", parse_dates=["日期"])

# ----------------------------------------------------------------------
# 10.1 多子图布局：subplots 网格
# ----------------------------------------------------------------------
print("【10.1 多子图布局】")
daily = sales.groupby("日期")["销售额"].sum().reset_index()

fig, axes = plt.subplots(2, 2, figsize=(11, 7))
# 左上：销售额趋势
axes[0, 0].plot(daily["日期"], daily["销售额"] / 10000, color=common_style.PALETTE["blue"], lw=1)
axes[0, 0].set_title("每日销售额（万元）")
axes[0, 0].tick_params(axis="x", labelsize=8)
# 右上：毛利 vs 销售额散点
axes[0, 1].scatter(sales["销售额"], sales["毛利"], s=8, alpha=0.3, color=common_style.PALETTE["teal"])
axes[0, 1].set_title("销售额 vs 毛利")
axes[0, 1].set_xlabel("销售额")
axes[0, 1].set_ylabel("毛利")
# 左下：评分分布
axes[1, 0].hist(sales["客户评分"], bins=[1.5, 2.5, 3.5, 4.5, 5.5], align="left",
                rwidth=0.7, color=common_style.PALETTE["orange"], edgecolor="white")
axes[1, 0].set_title("客户评分分布")
axes[1, 0].set_xticks([2, 3, 4, 5])
# 右下：各区域销售额柱状图
reg = sales.groupby("区域")["销售额"].sum().sort_values()
axes[1, 1].barh(reg.index, reg.values / 10000, color=common_style.PALETTE["purple"])
axes[1, 1].set_title("各区域销售额（万元）")
axes[1, 1].set_xlabel("万元")
fig.suptitle("电商销售数据四宫格概览", fontsize=15, fontweight="bold")
fig.tight_layout()
fig.savefig(f"{IMG}/fig_adv_grid.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_adv_grid.png")

# ----------------------------------------------------------------------
# 10.2 双 Y 轴：不同量纲的数据同图呈现
# ----------------------------------------------------------------------
print("\n【10.2 双 Y 轴】")
stock2 = stock.set_index("日期").loc["2023-06":"2023-09"]
fig, ax1 = plt.subplots(figsize=(10, 4.6))
ax1.plot(stock2.index, stock2["收盘"], color=common_style.PALETTE["blue"], lw=2, label="收盘价")
ax1.set_ylabel("收盘价（元）", color=common_style.PALETTE["blue"])
ax1.tick_params(axis="y", labelcolor=common_style.PALETTE["blue"])

ax2 = ax1.twinx()
ax2.bar(stock2.index, stock2["成交量(手)"], color=common_style.PALETTE["gray"],
        alpha=0.4, width=0.8, label="成交量")
ax2.set_ylabel("成交量（手）", color=common_style.PALETTE["gray"])
ax2.tick_params(axis="y", labelcolor=common_style.PALETTE["gray"])
ax1.set_title("股价与成交量（双 Y 轴）")
fig.tight_layout()
fig.savefig(f"{IMG}/fig_adv_twinx.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_adv_twinx.png")

# ----------------------------------------------------------------------
# 10.3 填充区域：highlight 特定区间
# ----------------------------------------------------------------------
print("\n【10.3 填充区域】")
w = weather.head(120)  # 前 4 个月
fig, ax = plt.subplots(figsize=(10, 4.4))
ax.fill_between(w["日期"], w["最低气温"], w["最高气温"], color=common_style.PALETTE["blue"],
                alpha=0.18, label="气温区间")
ax.plot(w["日期"], w["最高气温"], color=common_style.PALETTE["red"], lw=1.6, label="最高气温")
ax.plot(w["日期"], w["最低气温"], color=common_style.PALETTE["blue"], lw=1.6, label="最低气温")
ax.axvspan(pd.Timestamp("2024-02-01"), pd.Timestamp("2024-02-29"),
           color=common_style.PALETTE["gold"], alpha=0.12, label="2 月（最冷）")
ax.set_title("2024 年 1~4 月气温走势（填充面积图）")
ax.set_ylabel("气温（℃）")
ax.legend(ncol=4, fontsize=9)
fig.tight_layout()
fig.savefig(f"{IMG}/fig_adv_fill.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_adv_fill.png")

# ----------------------------------------------------------------------
# 10.4 注释与标注：让重点自己跳出来
# ----------------------------------------------------------------------
print("\n【10.4 注释与标注】")
monthly = sales.groupby(sales["日期"].dt.month)["销售额"].sum()
fig, ax = plt.subplots(figsize=(9, 4.4))
ax.plot(monthly.index, monthly.values / 10000, marker="o", color=common_style.PALETTE["blue"])
ax.annotate("双 11 销售高峰", xy=(11, monthly[11] / 10000),
            xytext=(8.2, monthly[11] / 10000 + 4),
            arrowprops=dict(arrowstyle="->", color=common_style.PALETTE["red"], lw=1.8),
            fontsize=12, fontweight="bold", color=common_style.PALETTE["red"])
ax.annotate("年货节小高峰", xy=(1, monthly[1] / 10000),
            xytext=(1.6, monthly[1] / 10000 - 6),
            arrowprops=dict(arrowstyle="->", color=common_style.PALETTE["orange"], lw=1.4),
            fontsize=10, color=common_style.PALETTE["orange"])
ax.set_xticks(monthly.index)
ax.set_xticklabels([f"{m}月" for m in monthly.index])
ax.set_title("月度销售额与关键节点标注")
ax.set_ylabel("销售额（万元）")
ax.grid(alpha=0.3)
fig.tight_layout()
fig.savefig(f"{IMG}/fig_adv_annotate.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_adv_annotate.png")

# ----------------------------------------------------------------------
# 10.5 颜色映射：数据到颜色的编码
# ----------------------------------------------------------------------
print("\n【10.5 颜色映射（scatter + cmap）】")
rng = np.random.default_rng(5)
x = rng.uniform(0, 10, 300)
y = rng.uniform(0, 10, 300)
z = np.sin(x) * np.cos(y) + rng.normal(0, 0.15, 300)
fig, ax = plt.subplots(figsize=(8, 4.8))
sc = ax.scatter(x, y, c=z, cmap="viridis", s=40, alpha=0.85, edgecolor="none")
cbar = fig.colorbar(sc, ax=ax, shrink=0.85)
cbar.set_label("目标值 z")
ax.set_title("散点图颜色映射（viridis 色带）")
ax.set_xlabel("x")
ax.set_ylabel("y")
fig.tight_layout()
fig.savefig(f"{IMG}/fig_adv_cmap.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_adv_cmap.png")

# ----------------------------------------------------------------------
# 10.6 样式定制：一图展示自定义主题能力
# ----------------------------------------------------------------------
print("\n【10.6 样式定制】")
fig, ax = plt.subplots(figsize=(8, 4.2))
x = np.linspace(0, 2 * np.pi, 200)
ax.plot(x, np.sin(x), color=common_style.PALETTE["blue"], lw=2.5, label="sin(x)")
ax.plot(x, np.cos(x), color=common_style.PALETTE["orange"], lw=2.5, ls="--", label="cos(x)")
ax.fill_between(x, np.sin(x), np.cos(x), where=(np.sin(x) > np.cos(x)),
                color=common_style.PALETTE["blue"], alpha=0.12)
ax.set_title("sin 与 cos：样式定制示例", pad=12)
ax.set_xlabel("角度（弧度）")
ax.set_ylabel("函数值")
ax.set_xticks([0, np.pi / 2, np.pi, 3 * np.pi / 2, 2 * np.pi])
ax.set_xticklabels(["0", "π/2", "π", "3π/2", "2π"])
ax.legend(frameon=True, fancybox=True, shadow=True, loc="upper right")
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
fig.tight_layout()
fig.savefig(f"{IMG}/fig_adv_style.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_adv_style.png")

# ----------------------------------------------------------------------
# 10.7 小彩蛋：极坐标图 + 3D 图
# ----------------------------------------------------------------------
print("\n【10.7 极坐标与 3D 图】")
fig = plt.figure(figsize=(12, 4.6))
ax1 = fig.add_subplot(121, projection="polar")
theta = np.linspace(0, 2 * np.pi, 36)
r_petal = 1 + 0.6 * np.sin(4 * theta)
ax1.plot(theta, r_petal, color=common_style.PALETTE["purple"], lw=2.2)
ax1.fill(theta, r_petal, color=common_style.PALETTE["purple"], alpha=0.25)
ax1.set_title("四叶草极坐标图")

ax2 = fig.add_subplot(122, projection="3d")
xx = np.linspace(-3, 3, 60)
yy = np.linspace(-3, 3, 60)
X, Y = np.meshgrid(xx, yy)
Z = np.sin(np.sqrt(X**2 + Y**2))
ax2.plot_surface(X, Y, Z, cmap="coolwarm", linewidth=0, antialiased=True, alpha=0.9)
ax2.set_title("3D 曲面图")
fig.tight_layout()
fig.savefig(f"{IMG}/fig_adv_polar3d.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_adv_polar3d.png")

print("\n✅ 第 10 章演示完成！")
