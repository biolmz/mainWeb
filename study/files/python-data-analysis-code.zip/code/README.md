# Python 数据分析与可视化 —— 示例代码包

本目录是《Python 数据分析与可视化：从 NumPy 到 matplotlib》教程的配套示例代码。

## 目录结构

```
code/
├── README.md                  # 本文件
├── requirements.txt           # 依赖清单
├── common_style.py            # 公共绘图配置（中文字体 + 主题）
├── 01_numpy入门.py            # 第2章：NumPy 基础
├── 02_numpy进阶.py            # 第3章：NumPy 进阶
├── 03_pandas入门.py           # 第4章：pandas 数据结构与读取
├── 04_pandas数据清洗.py       # 第5章：数据清洗
├── 05_pandas分组聚合.py       # 第6章：分组聚合与透视
├── 06_pandas合并与时间序列.py # 第7章：多表合并与时间序列
├── 07_数据分析方法.py         # 第8章：统计分析与特征工程
├── 08_matplotlib基础.py       # 第9章：matplotlib 基础
├── 09_matplotlib进阶.py       # 第10章：matplotlib 进阶
├── 10_综合实战.py             # 第11章：综合实战
├── data/                      # 演示数据集（与代码目录同级的 data/）
└── fonts/                     # 思源黑体（可选，用于无中文字体环境）
```

## 快速开始

### 1. 安装依赖

```bash
# 建议使用 Anaconda 或 venv 虚拟环境
pip install -r requirements.txt
```

### 2. 运行示例

```bash
cd code
python 01_numpy入门.py
python 08_matplotlib基础.py
```

> 图表默认输出到 `../images/` 目录（自动创建）。

### 3. 中文显示说明

- Windows：自动使用「微软雅黑」，无需配置；
- macOS：自动使用「苹方」，无需配置；
- Linux / 无中文字体环境：将 `fonts/` 目录（思源黑体）放在 `code/` 同级或 `code/fonts/` 下即可，脚本会自动注册。

## 数据集说明

| 文件 | 内容 | 规模 |
|---|---|---|
| `data/sales_2024.csv` | 2024 年电商订单（区域、品类、价格、毛利、评分、会员） | 1500 行 × 14 列 |
| `data/weather_daily.csv` | 某城市 2024 年逐日天气 | 366 行 × 8 列 |
| `data/students_scores.csv` | 学生六科成绩 | 120 行 × 11 列 |
| `data/stock_daily.csv` | 股票日线（OHLC + 成交量） | 500 行 × 7 列 |
| `data/tips.csv` | 餐厅小费数据（经典教学数据） | 244 行 × 7 列 |

## 建议学习顺序

`01 → 02 → 03 → 04 → 05 → 06 → 07 → 08 → 09 → 10`，前 7 章为数据处理，
第 8~10 章为可视化，第 11 章综合运用。也可以按需跳读，每个脚本互相独立。
