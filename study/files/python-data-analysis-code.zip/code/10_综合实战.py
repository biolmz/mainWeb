# -*- coding: utf-8 -*-
"""
第 11 章  综合实战：电商销售数据分析全流程
===========================================
把前几章的知识串起来，完成一次"加载 → 清洗 → 分析 → 可视化 → 结论"的完整分析。

分析对象：data/sales_2024.csv（2024 年 1500 笔电商订单）

运行方式：
    cd code
    python 10_综合实战.py
"""
import numpy as np
import pandas as pd
import common_style

common_style.setup()
import matplotlib.pyplot as plt  # noqa: E402
import seaborn as sns

IMG = common_style.img_dir()

print("#" * 62)
print("#  综合实战：2024 年电商销售数据分析")
print("#" * 62)

# ----------------------------------------------------------------------
# 第 1 步：加载数据
# ----------------------------------------------------------------------
sales = pd.read_csv("data/sales_2024.csv", parse_dates=["日期"])
print("\n[1] 数据加载完成：", sales.shape)

# ----------------------------------------------------------------------
# 第 2 步：数据清洗
# ----------------------------------------------------------------------
print("\n[2] 数据清洗")
print("缺失值总数:", int(sales.isna().sum().sum()))
print("重复行数:", sales.duplicated().sum())
sales = sales.drop_duplicates().dropna()

q1, q3 = sales["销量"].quantile([0.25, 0.75])
upper = q3 + 1.5 * (q3 - q1)
n_out = (sales["销量"] > upper).sum()
sales = sales[sales["销量"] <= upper]
print(f"剔除异常高销量订单 {n_out} 行（IQR 上限 {upper:.0f}），清洗后: {sales.shape}")

sales["月份"] = sales["日期"].dt.month
sales["季度"] = sales["月份"].map({1: "Q1", 2: "Q1", 3: "Q1", 4: "Q2", 5: "Q2", 6: "Q2",
                                   7: "Q3", 8: "Q3", 9: "Q3", 10: "Q4", 11: "Q4", 12: "Q4"})

# ----------------------------------------------------------------------
# 第 3 步：整体经营概览
# ----------------------------------------------------------------------
print("\n[3] 经营概览")
total_amount = sales["销售额"].sum()
total_gross = sales["毛利"].sum()
print(f"全年销售额: {total_amount / 10000:.1f} 万元")
print(f"全年毛利:   {total_gross / 10000:.1f} 万元（毛利率 {total_gross / total_amount * 100:.1f}%）")
print(f"总订单数:   {len(sales)} 单，平均客单价 {total_amount / len(sales):.0f} 元")
print(f"平均评分:   {sales['客户评分'].mean():.2f} / 5")

# ----------------------------------------------------------------------
# 第 4 步：趋势分析（月度 + 季度）
# ----------------------------------------------------------------------
print("\n[4] 趋势分析")
monthly = sales.groupby("月份").agg(销售额=("销售额", "sum"), 订单数=("订单号", "count"))
print("月度销售表现（销售额万元 / 订单数）:")
print((monthly.assign(销售额=monthly["销售额"] / 10000)).round(1).to_string())
peak = monthly["销售额"].idxmax()
print(f"销售高峰出现在 {peak} 月（双 11 效应明显）")

# ----------------------------------------------------------------------
# 第 5 步：品类与区域分析
# ----------------------------------------------------------------------
print("\n[5] 品类 × 区域分析")
cat_top = sales.groupby("品类")["销售额"].sum().sort_values(ascending=False)
print("品类销售额 Top 3:", " > ".join([f"{k}({v / 10000:.0f}万)" for k, v in cat_top.head(3).items()]))

region_share = sales.groupby("区域")["销售额"].sum() / total_amount
print("区域销售占比:", "、".join([f"{k} {v * 100:.0f}%" for k, v in region_share.sort_values(ascending=False).items()]))

# 区域×品类交叉：谁是华东的拳头品类？
cross = sales[sales["区域"] == "华东"].groupby("品类")["销售额"].sum().sort_values(ascending=False)
print("华东区域销售额最高的品类:", cross.index[0], f"（{cross.iloc[0] / 10000:.0f} 万元）")
# ----------------------------------------------------------------------
# 第 6 步：会员与支付分析
# ----------------------------------------------------------------------
print("\n[6] 会员与支付分析")
member_order = sales.groupby("会员等级").agg(订单数=("订单号", "count"), 销售额=("销售额", "sum"))
member_order["客单价"] = member_order["销售额"] / member_order["订单数"]
print("会员等级分析:")
print(member_order.round(0).to_string())
print("普通会员订单数占比 {:.0f}%，是绝对的订单主力".format(
    member_order.loc["普通会员", "订单数"] / member_order["订单数"].sum() * 100))

# ----------------------------------------------------------------------
# 第 7 步：相关性洞察
# ----------------------------------------------------------------------
print("\n[7] 相关性分析")
corr = sales[["销量", "单价", "销售额", "毛利", "客户评分"]].corr()
print("关键变量相关系数:")
print(corr.round(2).to_string())

# ----------------------------------------------------------------------
# 第 8 步：一页纸"经营仪表盘"
# ----------------------------------------------------------------------
print("\n[8] 生成经营仪表盘图表")
fig = plt.figure(figsize=(14, 10))
gs = fig.add_gridspec(3, 3, hspace=0.45, wspace=0.3)

# 1. 月度销售额趋势
ax = fig.add_subplot(gs[0, :])
ax.plot(monthly.index, monthly["销售额"] / 10000, marker="o", color="#2563eb", lw=2.4)
ax.annotate("双 11 峰值", xy=(11, monthly.loc[11, "销售额"] / 10000),
            xytext=(8, monthly.loc[11, "销售额"] / 10000 + 5),
            arrowprops=dict(arrowstyle="->", color="#dc2626"), color="#dc2626", fontsize=11, fontweight="bold")
ax.set_title("① 月度销售额趋势（万元）")
ax.set_xticks(range(1, 13))
ax.grid(alpha=0.3)

# 2. 品类销售额
ax = fig.add_subplot(gs[1, 0])
ax.bar(cat_top.index, cat_top.values / 10000, color=["#2563eb", "#0d9488", "#f97316", "#7c3aed", "#16a34a", "#f59e0b"])
ax.set_title("② 品类销售额（万元）")
ax.tick_params(axis="x", rotation=25, labelsize=9)

# 3. 区域占比
ax = fig.add_subplot(gs[1, 1])
ax.pie(region_share.values, labels=region_share.index, autopct="%.0f%%", colors=["#2563eb", "#0d9488", "#f97316", "#7c3aed", "#16a34a", "#f59e0b"])
ax.set_title("③ 区域销售占比")

# 4. 会员客单价
ax = fig.add_subplot(gs[1, 2])
member_avg = member_order["客单价"].reindex(["普通会员", "白银会员", "黄金会员", "铂金会员"])
ax.bar(member_avg.index, member_avg.values, color="#0d9488", alpha=0.85)
for i, v in enumerate(member_avg.values):
    ax.text(i, v + 20, f"{v:.0f}", ha="center", fontsize=10, fontweight="bold")
ax.set_title("④ 各等级会员客单价（元）")
ax.tick_params(axis="x", rotation=15, labelsize=9)

# 5. 相关性热力图
ax = fig.add_subplot(gs[2, 0])
sns.heatmap(corr, annot=True, fmt=".2f", cmap="RdBu_r", center=0, cbar=False,
            square=True, linewidths=0.5, ax=ax, annot_kws={"fontsize": 8})
ax.set_title("⑤ 关键变量相关性")

# 6. 评分分布
ax = fig.add_subplot(gs[2, 1])
scores_hist = sales["客户评分"]
ax.hist(scores_hist, bins=[1.5, 2.5, 3.5, 4.5, 5.5], align="left", rwidth=0.6,
        color="#f97316", edgecolor="white")
ax.set_xticks([2, 3, 4, 5])
ax.set_title("⑥ 客户评分分布")
ax.set_xlabel("评分")

# 7. 星期热力（星期×时段订单量）
ax = fig.add_subplot(gs[2, 2])
week_pivot = pd.crosstab(sales["日期"].dt.day_name(), sales["支付方式"])
sns.heatmap(week_pivot, annot=True, fmt="d", cmap="YlGnBu", cbar=False,
            linewidths=0.5, ax=ax, annot_kws={"fontsize": 8})
ax.set_title("⑦ 星期 × 支付方式 订单量")
ax.tick_params(axis="x", rotation=30, labelsize=8)
ax.set_ylabel("")

fig.suptitle("2024 电商销售经营仪表盘", fontsize=17, fontweight="bold", y=0.98)
fig.savefig(f"{IMG}/fig_final_dashboard.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_final_dashboard.png")

# ----------------------------------------------------------------------
# 第 9 步：分析结论
# ----------------------------------------------------------------------
print("\n[9] 分析结论")
conclusions = [
    "1. 销售季节性明显：11 月（双 11）为全年峰值，10 月（国庆 + 大促预热）次之，",
    "   6 月（618）形成第三个小高峰；建议围绕大促节点提前备货与营销蓄水，",
    "   并通过淡季主题活动平滑月度波动。",
    "2. 华东、华北合计贡献约 47% 营收，华南紧随其后（22.6%）；",
    "   服饰鞋包与数码家电是两大支柱品类，华东区域以服饰鞋包为拳头品类；",
    "   建议按区域消费偏好差异化选品，西南、东北、西北可结合本地特色拓展供给。",
    "3. 普通会员贡献 45% 的订单量，是订单基本盘；各等级客单价差异不大（约 0.8~0.86 万元），",
    "   说明当前会员分层尚未形成明显溢价；建议设计阶梯权益（运费券、专属价、",
    "   积分加速）推动普通会员向白银/黄金升级，扩大高价值客户基数。",
    "4. 客户评分以 4~5 分为主（约 79%），整体体验良好；但仍有约 21% 订单评 3 分及以下，",
    "   建议下钻分析差评订单集中的品类与区域，针对性改进履约与售后。",
    "5. 销售额与毛利高度相关（r≈0.94），定价结构健康；下一步可接入退货率、复购率、",
    "   营销 ROI 等指标，把分析延伸到经营全链路。",
]
for c in conclusions:
    print(c)

print("\n✅ 综合实战完成！图表与结论已输出。")
