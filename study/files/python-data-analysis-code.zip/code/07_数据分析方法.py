# -*- coding: utf-8 -*-
"""
第 8 章  数据分析常用方法
=========================
包含：描述性统计 / 相关性分析 / 假设检验（t 检验、卡方检验）/ 线性回归 / 特征工程

"数据不会说话，方法才能让数据开口。"

运行方式：
    cd code
    python 07_数据分析方法.py
"""
import numpy as np
import pandas as pd
import common_style

common_style.setup()
import matplotlib.pyplot as plt  # noqa: E402
import seaborn as sns
from scipy import stats
from sklearn.preprocessing import StandardScaler

IMG = common_style.img_dir()

# ----------------------------------------------------------------------
# 8.1 描述性统计：分布的形状
# ----------------------------------------------------------------------
print("【8.1 描述性统计】")
scores = pd.read_csv("data/students_scores.csv")
score_cols = ["语文", "数学", "英语", "物理", "化学", "生物"]
print(scores[score_cols].describe().round(2).to_string())

print("\n偏度（>0 右偏，<0 左偏）:")
print(scores[score_cols].skew().round(2).to_string())
print("\n峰度（正态≈0，>0 更尖）:")
print(scores[score_cols].kurtosis().round(2).to_string())

# 生动结论
math = scores["数学"]
print(f"\n数学最高 {math.max():.0f} 分、最低 {math.min():.0f} 分，"
      f"及格率 {(math >= 60).mean() * 100:.0f}%，优秀率 {(math >= 90).mean() * 100:.0f}%")

# ----------------------------------------------------------------------
# 8.2 相关性分析
# ----------------------------------------------------------------------
print("\n【8.2 相关性分析】")
corr = scores[score_cols].corr(method="pearson")
print("科目间相关系数矩阵:")
print(corr.round(3).to_string())
print("\n数学与物理相关性最高:", corr["数学"].drop("数学").idxmax(),
      "r =", round(corr.loc["数学", "物理"], 3))

tips = pd.read_csv("data/tips.csv")
print("\n小费数据：总消费与小费的相关性 r =",
      round(tips["总消费"].corr(tips["小费"]), 3))

# 斯皮尔曼秩相关（对非线性/异常值更稳健）
print("斯皮尔曼相关 r =", round(tips["总消费"].corr(tips["小费"], method="spearman"), 3))

# 热力图
fig, ax = plt.subplots(figsize=(7.5, 6))
sns.heatmap(corr, annot=True, fmt=".2f", cmap="RdBu_r", center=0,
            square=True, linewidths=0.6, cbar_kws={"shrink": 0.8}, ax=ax)
ax.set_title("六科成绩相关系数热力图")
fig.tight_layout()
fig.savefig(f"{IMG}/fig_stats_corr.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_stats_corr.png")

# ----------------------------------------------------------------------
# 8.3 假设检验：独立样本 t 检验
# ----------------------------------------------------------------------
print("\n【8.3 独立样本 t 检验】")
male = scores.loc[scores["性别"] == "男", "数学"]
female = scores.loc[scores["性别"] == "女", "数学"]
t_stat, p_value = stats.ttest_ind(male, female)
print(f"男生数学: 均值 {male.mean():.2f}（n={len(male)}），女生: 均值 {female.mean():.2f}（n={len(female)}）")
print(f"t = {t_stat:.3f}, p = {p_value:.4f}")
print("结论：", "差异显著（p<0.05），男女生数学成绩有统计差异"
      if p_value < 0.05 else "差异不显著（p≥0.05），不能认为男女生数学成绩有差异")

# ----------------------------------------------------------------------
# 8.4 卡方检验：分类变量的独立性
# ----------------------------------------------------------------------
print("\n【8.4 卡方独立性检验】")
ct = pd.crosstab(tips["性别"], tips["是否吸烟"])
print("性别 × 是否吸烟 交叉表:")
print(ct.to_string())
chi2, p2, dof, _ = stats.chi2_contingency(ct)
print(f"chi2 = {chi2:.3f}, p = {p2:.4f}, 自由度 = {dof}")
print("结论：", "性别与吸烟习惯有关联（p<0.05）"
      if p2 < 0.05 else "性别与吸烟习惯无明显关联（p≥0.05）")

# ----------------------------------------------------------------------
# 8.5 线性回归（statsmodels 风格，用 scipy 近似演示）
# ----------------------------------------------------------------------
print("\n【8.5 线性回归】")
# 用 numpy 最小二乘拟合：总消费 → 小费
X = np.column_stack([np.ones(len(tips)), tips["总消费"]])
beta = np.linalg.lstsq(X, tips["小费"], rcond=None)[0]
print(f"小费 = {beta[0]:.3f} + {beta[1]:.3f} × 总消费（每多消费 10 元约多给 {beta[1]*10:.2f} 元小费）")
residual = tips["小费"] - X @ beta
r2 = 1 - (residual**2).sum() / ((tips["小费"] - tips["小费"].mean())**2).sum()
print(f"R² = {r2:.3f}（总消费能解释 {r2*100:.1f}% 的小费变化）")

fig, ax = plt.subplots(figsize=(8, 4.6))
ax.scatter(tips["总消费"], tips["小费"], s=30, alpha=0.6, color=common_style.PALETTE["blue"], label="样本")
xs = np.linspace(tips["总消费"].min(), tips["总消费"].max(), 50)
ax.plot(xs, beta[0] + beta[1] * xs, color=common_style.PALETTE["red"], lw=2.5,
        label=f"拟合线: y={beta[1]:.2f}x{beta[0]:+.2f}，R²={r2:.2f}")
ax.set_title("餐厅总消费与小费的关系（线性回归）")
ax.set_xlabel("总消费（元）")
ax.set_ylabel("小费（元）")
ax.legend()
fig.tight_layout()
fig.savefig(f"{IMG}/fig_stats_regression.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_stats_regression.png")

# ----------------------------------------------------------------------
# 8.6 特征工程基础
# ----------------------------------------------------------------------
print("\n【8.6 特征工程】")
# 哑变量：把分类变量变成 0/1
dummies = pd.get_dummies(tips["用餐时段"], prefix="时段")
print("用餐时段哑变量（前 3 行）:")
print(pd.concat([tips["用餐时段"], dummies], axis=1).head(3).to_string(index=False))

# 分箱：连续值离散化
tips2 = tips.copy()
tips2["消费档位"] = pd.cut(tips2["总消费"], bins=[0, 20, 40, 100], labels=["低", "中", "高"])
print("\n消费档位分布:")
print(tips2["消费档位"].value_counts().to_string())

# 标准化：消除量纲影响
scaler = StandardScaler()
norm = scaler.fit_transform(scores[["数学", "英语"]])
norm_df = pd.DataFrame(norm, columns=["数学_z", "英语_z"])
print("\n标准化后的数学成绩（均值≈0，标准差≈1）:")
print(norm_df["数学_z"].describe().round(3).to_string())

# 直方图对比：原始 vs 标准化
fig, axes = plt.subplots(1, 2, figsize=(9, 3.8), sharey=True)
axes[0].hist(scores["数学"], bins=15, color=common_style.PALETTE["blue"], alpha=0.75, edgecolor="white")
axes[0].set_title("原始数学成绩分布")
axes[0].set_xlabel("分数")
axes[1].hist(norm[:, 0], bins=15, color=common_style.PALETTE["teal"], alpha=0.75, edgecolor="white")
axes[1].set_title("标准化后的数学成绩")
axes[1].set_xlabel("Z 分数")
for ax in axes:
    ax.set_ylabel("人数")
fig.tight_layout()
fig.savefig(f"{IMG}/fig_stats_scale.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_stats_scale.png")

print("\n✅ 第 8 章演示完成！")
