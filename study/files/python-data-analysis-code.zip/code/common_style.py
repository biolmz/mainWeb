# -*- coding: utf-8 -*-
"""
common_style —— 本教程公共绘图配置模块
========================================
统一配置 matplotlib 中文字体与主题，让所有图表在中文环境下一键可运行。

用法（在任意示例脚本顶部）：
    import common_style
    common_style.setup()

如果脚本需要输出图表到 images 目录：
    IMG = common_style.img_dir()   # 返回项目 images 目录（不存在则自动创建）
"""
import os

import matplotlib
import matplotlib.pyplot as plt
from matplotlib import font_manager

# 优先注册随教程附带的思源黑体（保证 Linux / 无中文字体环境可用）
_FONT_CANDIDATES = [
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts", "NotoSansCJKsc-Regular.otf"),
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "fonts", "NotoSansCJKsc-Regular.otf"),
]

# 常见系统中文字体回退顺序（Windows / macOS / Linux 均可命中）
_FONT_FALLBACK = [
    "Noto Sans CJK SC", "Microsoft YaHei", "SimHei",
    "PingFang SC", "Hiragino Sans GB", "WenQuanYi Zen Hei",
]

# 教程统一的配色（清爽、专业的蓝绿色系）
PALETTE = {
    "blue":   "#2563eb",
    "teal":   "#0d9488",
    "orange": "#f97316",
    "red":    "#dc2626",
    "purple": "#7c3aed",
    "green":  "#16a34a",
    "gray":   "#94a3b8",
    "gold":   "#f59e0b",
}
COLORS = list(PALETTE.values())


def _register_fonts():
    """注册随教程附带的字体文件（若存在）。"""
    for fp in _FONT_CANDIDATES:
        if os.path.exists(fp):
            try:
                font_manager.fontManager.addfont(fp)
            except Exception:
                pass
            return


def setup(style: str = "light", dpi: int = 110) -> None:
    """
    初始化绘图环境。

    参数
    ----
    style : "light" 或 "dark"
    dpi   : 全局默认分辨率（影响文字与线条清晰度）
    """
    _register_fonts()
    matplotlib.rcdefaults()
    if style == "dark":
        plt.style.use("dark_background")
    else:
        plt.style.use("seaborn-v0_8-whitegrid")
    plt.rcParams.update({
        "font.sans-serif": _FONT_FALLBACK,
        "font.family":     "sans-serif",
        "axes.unicode_minus": False,     # 正常显示负号
        "figure.dpi":      dpi,
        "savefig.dpi":     160,          # 保存图片的高分辨率
        "font.size":       12,
        "axes.titlesize":  14,
        "axes.labelsize":  12,
        "axes.titleweight": "bold",
        "figure.facecolor": "white",
        "axes.facecolor":   "white",
        "lines.linewidth":  2.2,
    })


def img_dir() -> str:
    """返回图片输出目录（项目根下的 images/），不存在则自动创建。"""
    d = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "images")
    os.makedirs(d, exist_ok=True)
    return d
