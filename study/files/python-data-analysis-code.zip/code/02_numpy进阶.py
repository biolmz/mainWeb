# -*- coding: utf-8 -*-
"""
第 3 章  NumPy 进阶技巧
=======================
包含：花式索引 / 布尔索引 / 形状变换 / 堆叠拼接 / 矩阵运算 / 随机数 / 文件读写 / 向量化性能

运行方式：
    cd code
    python 02_numpy进阶.py
"""
import time

import numpy as np
import common_style

common_style.setup()
import matplotlib.pyplot as plt  # noqa: E402

IMG = common_style.img_dir()

# ----------------------------------------------------------------------
# 3.1 花式索引：用整数数组一次性取多个位置
# ----------------------------------------------------------------------
print("【3.1 花式索引】")
arr = np.arange(12)**2
print("arr =", arr)
idx = np.array([0, 3, 7])
print("arr[[0,3,7]] =", arr[idx], "   # 取出第 1、4、8 个元素")

# 生动例子：模拟一场马拉松比赛的成绩（秒），取出冠亚季军
results = np.array([3480, 3312, 3595, 3260, 3418, 3620, 3299, 3550])
ranks = np.argsort(results)          # 按成绩升序排序的索引
print("\n马拉松成绩(秒):", results)
print("排名（用时从少到多）:", ranks + 1, "号选手")
print("冠亚季军成绩:", results[ranks[:3]], "秒")

# ----------------------------------------------------------------------
# 3.2 布尔索引：按条件筛选，数据分析里最常用的操作之一
# ----------------------------------------------------------------------
print("\n【3.2 布尔索引】")
temps = np.array([12, 15, 18, 22, 25, 20, 8, 30])
print("气温:", temps)
print("气温 > 20℃ 的天数:", (temps > 20).sum())
print("气温 > 20℃ 的值:", temps[temps > 20])
print("温和区间(15~25):", temps[(temps >= 15) & (temps <= 25)])

# 应用：从模拟销量中筛出"爆款"（销量超过均值 1.5 倍）
sales = np.array([120, 340, 90, 410, 260, 500, 150, 380])
threshold = sales.mean() * 1.5
print("\n销量:", sales, " 阈值:", round(threshold, 1))
print("爆款销量:", sales[sales > threshold])

# ----------------------------------------------------------------------
# 3.3 形状变换与堆叠
# ----------------------------------------------------------------------
print("\n【3.3 形状变换与堆叠】")
v = np.arange(1, 13)
print("v =", v)
print("reshape(3,4):\n", v.reshape(3, 4))
print("reshape(-1,2)（自动推断行数）:\n", v.reshape(-1, 2))
print("ravel 展平:", v.reshape(3, 4).ravel())
print("transpose 转置:\n", v.reshape(3, 4).T)

a1 = np.array([[1, 2], [3, 4]])
a2 = np.array([[5, 6]])
print("\n纵向拼接 vstack:\n", np.vstack([a1, a2]))
print("横向拼接 hstack:\n", np.hstack([a1, np.array([[7], [8]])]))

# ----------------------------------------------------------------------
# 3.4 矩阵运算：点积、线性方程组
# ----------------------------------------------------------------------
print("\n【3.4 矩阵运算】")
A = np.array([[2, 1], [1, 3]])
B = np.array([[1, 2], [0, 1]])
print("A =", A.tolist(), " B =", B.tolist())
print("A @ B =\n", A @ B)                 # 矩阵乘法
print("det(A) =", round(np.linalg.det(A), 4))

# 解线性方程组：2x + y = 5, x + 3y = 10
coef = np.array([[2, 1], [1, 3]])
rhs = np.array([5, 10])
sol = np.linalg.solve(coef, rhs)
print("\n方程 2x+y=5, x+3y=10 的解: x =", round(sol[0], 2), " y =", round(sol[1], 2))
print("验证: 2x+y =", 2 * sol[0] + sol[1], " ✓")

# ----------------------------------------------------------------------
# 3.5 随机数：仿真与抽样的基础
# ----------------------------------------------------------------------
print("\n【3.5 随机数】")
rng = np.random.default_rng(42)          # 固定种子，保证可复现
u = rng.uniform(0, 1, 5)                 # 均匀分布
n1 = rng.normal(0, 1, 5)                 # 标准正态分布
print("均匀分布 U(0,1):", np.round(u, 3))
print("正态分布 N(0,1):", np.round(n1, 3))
print("random.randint 掷骰子 10 次:", rng.integers(1, 7, 10))

# 可视化：正态分布随机数直方图（大数定律的直观体现）
samples = rng.normal(170, 6, 5000)       # 模拟 5000 人身高，均值170、标准差6
fig, ax = plt.subplots(figsize=(8, 4.2))
ax.hist(samples, bins=40, color=common_style.PALETTE["teal"], alpha=0.8,
        edgecolor="white", label=f"样本均值 {samples.mean():.2f}")
ax.axvline(samples.mean(), color=common_style.PALETTE["red"], lw=2, label="样本均值")
ax.set_title("模拟 5000 人身高分布（近似正态分布 N(170, 6)）")
ax.set_xlabel("身高（cm）")
ax.set_ylabel("人数")
ax.legend()
fig.tight_layout()
fig.savefig(f"{IMG}/fig_np_histogram.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_np_histogram.png")

# ----------------------------------------------------------------------
# 3.6 文件读写
# ----------------------------------------------------------------------
print("\n【3.6 文件读写】")
m = np.arange(1, 13).reshape(3, 4)
np.save("tmp_matrix.npy", m)
loaded = np.load("tmp_matrix.npy")
print("np.save/load 保存并读回:\n", loaded)
np.savetxt("tmp_matrix.csv", m, delimiter=",", fmt="%d")
loaded2 = np.loadtxt("tmp_matrix.csv", delimiter=",")
print("np.savetxt 保存为 CSV 并读回:\n", loaded2.astype(int))

# ----------------------------------------------------------------------
# 3.7 向量化的威力：对比 Python 循环与 numpy
# ----------------------------------------------------------------------
print("\n【3.7 向量化 vs 循环 性能对比】")
big = rng.normal(size=5_000_000)

t0 = time.perf_counter()
loop_sum = sum(x * 2 + 1 for x in big)          # 纯 Python 循环
t_loop = time.perf_counter() - t0

t0 = time.perf_counter()
vec_sum = (big * 2 + 1).sum()                    # numpy 向量化
t_vec = time.perf_counter() - t0

print(f"Python 循环: {t_loop * 1000:8.1f} ms   结果 {loop_sum:.1f}")
print(f"numpy 向量化: {t_vec * 1000:8.1f} ms   结果 {vec_sum:.1f}")
print(f"向量化快约 {t_loop / t_vec:.0f} 倍")

# ----------------------------------------------------------------------
# 3.8 实战小案例：用 numpy 实现简单线性回归（最小二乘法）
# ----------------------------------------------------------------------
print("\n【3.8 用 numpy 实现最小二乘线性回归】")
# 模拟身高与体重数据
rng = np.random.default_rng(7)
height = rng.normal(170, 6, 200)
weight = 0.62 * height - 42 + rng.normal(0, 4, 200)     # 真实关系 y=0.62x-42

# 最小二乘解: (X^T X)^-1 X^T y
X = np.column_stack([np.ones_like(height), height])
beta = np.linalg.inv(X.T @ X) @ X.T @ weight
print(f"拟合结果: 体重 = {beta[0]:.2f} + {beta[1]:.2f} × 身高")
print(f"理论关系: 体重 = -42.00 + 0.62 × 身高（非常接近！）")

xs = np.linspace(height.min(), height.max(), 100)
ys = beta[0] + beta[1] * xs
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.scatter(height, weight, s=18, alpha=0.55, color=common_style.PALETTE["blue"], label="样本数据")
ax.plot(xs, ys, color=common_style.PALETTE["red"], lw=2.5, label=f"回归线  y={beta[1]:.2f}x{beta[0]:+.1f}")
ax.set_title("身高与体重关系（numpy 最小二乘回归）")
ax.set_xlabel("身高（cm）")
ax.set_ylabel("体重（kg）")
ax.legend()
fig.tight_layout()
fig.savefig(f"{IMG}/fig_np_regression.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_np_regression.png")

print("\n✅ 第 3 章（进阶篇）演示完成！")
