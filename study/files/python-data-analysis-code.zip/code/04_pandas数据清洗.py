# -*- coding: utf-8 -*-
"""
第 5 章  数据清洗：分析前最重要的 20% 工作
===========================================
包含：缺失值处理 / 重复值处理 / 异常值检测 / 类型转换 / 文本处理

真实数据分析中，清洗往往占据一半以上的时间。"垃圾进，垃圾出"——
先别急着分析，先把数据弄干净。

运行方式：
    cd code
    python 04_pandas数据清洗.py
"""
import numpy as np
import pandas as pd
import common_style

common_style.setup()
import matplotlib.pyplot as plt  # noqa: E402

IMG = common_style.img_dir()

# ----------------------------------------------------------------------
# 5.1 构造一份"脏"数据：模拟销售系统导出的混乱表格
# ----------------------------------------------------------------------
print("【5.1 构造脏数据】")
dirty = pd.DataFrame({
    "订单号": ["A001", "A002", "A002", "A003", "A004", "A005", "A006", None],
    "日期":   ["2024-03-01", "2024-03-02", "2024-03-02", "2024/3/3", "2024-03-05",
               "2024-03-06", "2024-03-07", "2024-03-08"],
    "商品":   [" 蓝牙耳机", "手机壳", "手机壳", "数据线", "充电宝", "蓝牙耳机", "数据线", "数据线"],
    "销量":   [2, 5, 5, 3, 8, 2, 999, 4],
    "单价":   ["199元", "29元", "29元", "15元", "99元", "199元", "9.9元", "15元"],
    "备注":   ["正常", np.nan, np.nan, "正常", "活动", "正常", "疑似异常", np.nan],
})
print(dirty)
print("\n缺失值概览 isna().sum():")
print(dirty.isna().sum())

# ----------------------------------------------------------------------
# 5.2 处理缺失值：dropna 删除 / fillna 填充
# ----------------------------------------------------------------------
print("\n【5.2 缺失值处理】")
print("删除含缺失值的行:")
print(dirty.dropna().shape, "→ 从", dirty.shape[0], "行降到", dirty.dropna().shape[0], "行")
print("填充：备注为空填'无'")
print(dirty["备注"].fillna("无").to_list())
print("数值列用均值填充（示例，仅演示）:")
print(dirty["销量"].fillna(dirty["销量"].mean()).round(1).to_list())

# 生动场景：天气数据里某几天缺了降水记录，用前后两天均值插补
weather = pd.read_csv("data/weather_daily.csv")
w_missing = weather.copy()
w_missing.loc[[10, 11, 12], "降水量"] = np.nan
print("\n模拟 1 月 11~13 日降水量缺失:")
print(w_missing.iloc[9:13, [0, 4]])
w_fill = w_missing["降水量"].ffill()                          # 前向填充
w_fill2 = w_missing["降水量"].interpolate()                  # 线性插值（更平滑）
print("前向填充:", w_fill.iloc[10:13].round(1).to_list())
print("线性插值:", w_fill2.iloc[10:13].round(1).to_list())

# ----------------------------------------------------------------------
# 5.3 处理重复值
# ----------------------------------------------------------------------
print("\n【5.3 重复值处理】")
print("重复行数 duplicated().sum():", dirty.duplicated().sum())
print("（A002 手机壳被重复录入了两次）")
clean1 = dirty.drop_duplicates()
print("drop_duplicates 后剩余:", len(clean1), "行")

# ----------------------------------------------------------------------
# 5.4 异常值检测：3σ 法则 与 IQR 法则
# ----------------------------------------------------------------------
print("\n【5.4 异常值检测】")
# 3σ 法则（正态假设）
sales = pd.read_csv("data/sales_2024.csv")
qty = sales["销量"]
mean_, std_ = qty.mean(), qty.std()
outlier_3sigma = qty[(qty < mean_ - 3 * std_) | (qty > mean_ + 3 * std_)]
print(f"销量均值 {mean_:.2f}，标准差 {std_:.2f}，3σ 异常值个数: {len(outlier_3sigma)}")
print("异常销量值:", sorted(outlier_3sigma.unique())[:10])

# IQR 法则（对偏态分布更稳健）
q1, q3 = qty.quantile(0.25), qty.quantile(0.75)
iqr = q3 - q1
lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
outlier_iqr = qty[(qty < lower) | (qty > upper)]
print(f"IQR 法: Q1={q1}, Q3={q3}, IQR={iqr:.1f}，下界 {lower:.1f}，上界 {upper:.1f}")
print("IQR 异常值个数:", len(outlier_iqr))

# 展示：清洗前后对比箱线图
sales_clean = sales[sales["销量"].between(lower, upper)]
fig, axes = plt.subplots(1, 2, figsize=(9, 4), sharey=True)
axes[0].boxplot(qty, vert=True, patch_artist=True,
                boxprops=dict(facecolor=common_style.PALETTE["orange"], alpha=0.7))
axes[0].set_title(f"清洗前（含 {len(outlier_iqr)} 个异常值）")
axes[1].boxplot(sales_clean["销量"], vert=True, patch_artist=True,
                boxprops=dict(facecolor=common_style.PALETTE["teal"], alpha=0.7))
axes[1].set_title(f"清洗后（{len(sales_clean)} 行）")
for ax in axes:
    ax.set_ylabel("单笔销量")
fig.suptitle("IQR 法则剔除异常值前后的销量分布对比")
fig.tight_layout()
fig.savefig(f"{IMG}/fig_clean_outlier.png", bbox_inches="tight")
print("已保存图表:", f"{IMG}/fig_clean_outlier.png")

# ----------------------------------------------------------------------
# 5.5 类型转换
# ----------------------------------------------------------------------
print("\n【5.5 类型转换】")
s1 = pd.Series(["1", "2", "3.5", "4.2"])
print("字符串→数值:", s1.astype(float).to_list())

# 真实场景：把字符串日期统一为 datetime
# 注意：pandas 3.0 起混合格式需指定 format="mixed"，自动推断已移除
dirty2 = dirty.copy()
dirty2["日期"] = pd.to_datetime(dirty2["日期"], format="mixed")
print("日期列解析为 datetime 后:\n", dirty2["日期"].dtype)
dirty2["月份"] = dirty2["日期"].dt.month
print("提取月份:", dirty2["月份"].to_list())

# 单价列"199元"这种带单位的文本 → 数值
price_str = dirty["单价"].str.replace("元", "").astype(float)
print("单价文本→数值:", price_str.to_list())

# ----------------------------------------------------------------------
# 5.6 文本处理：str 方法家族
# ----------------------------------------------------------------------
print("\n【5.6 文本处理】")
goods = pd.Series(["  蓝牙耳机 ", "手机壳", "数据线 ", " 充电宝"])
print("去空格 strip:", goods.str.strip().to_list())
print("是否含'耳机':", goods.str.strip().str.contains("耳机").to_list())
desc = pd.Series(["春季大促，全场5折", "新品上架", "限时秒杀"])
print("按逗号分词:", desc.str.split("，").to_list())
print("替换:", desc.str.replace("，", " / ").to_list())

# 真实场景：从完整商品名里判断品类
name = pd.Series(["苹果 iPhone15 256G 手机", "华为 Mate60 手机", "联想 小新Pro 笔记本"])
print("\n含'手机'的商品:", name[name.str.contains("手机")].to_list())

print("\n✅ 第 5 章演示完成！")
